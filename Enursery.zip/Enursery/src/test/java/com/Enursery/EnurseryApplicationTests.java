package com.Enursery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.Enursery.Nursery.EnurseryApplication;
@SpringBootTest(classes=EnurseryApplication.class)
class EnurseryApplicationTests {

	@Test
	void contextLoads() {
	}

}
