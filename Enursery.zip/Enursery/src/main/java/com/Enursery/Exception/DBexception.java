package com.Enursery.Exception;



public class DBexception extends Exception
{

public DBexception(String msg) {
super(msg);
}
}