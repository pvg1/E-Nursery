package com.Enursery.Exception;



public class RecordNotFound extends Exception {
public RecordNotFound(String msg) {
super(msg);
}



}